import Navbar from "@/components/Navbar"
import React from "react"

const page = () => {
    return (
        <>
        <Navbar/>
         <section className="bg-gray-100">
          
         </section>
        </>
    )
}
export default page