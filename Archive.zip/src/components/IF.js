export const IF = ({condition, children}) => {
    return condition ? children : null
}
